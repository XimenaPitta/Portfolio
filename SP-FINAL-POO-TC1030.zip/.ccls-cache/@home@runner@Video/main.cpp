#include <iostream>
#include <vector>
#include <map>
#include <fstream>
#include <string>
#include <sstream>
#include "Movie.h"
#include "Serie.h"
#include "Episode.h"
using namespace std;

int main() {

  // EXTRAER DATOS DE ARCHIVOS .TXT Y CONVERTIRLOS A OBJETOS
  // 1. Lectura de archivos .txt para películas (herencia video)
    ifstream file("Peliculas.txt");
    vector<Movie*> movies;
    map<string, vector<Movie*>> genreMap;
    map<double, vector<Movie*>> ratingMap;

    if (!file.is_open()) {
        cout << "Error: Unable to open file." << endl;
        return 1; // Return an error code
    }

    string line;
    while (getline(file, line)) {
        stringstream ss(line);
        string token;
        int id;
        string name, genre;
        //double duration, rating;
        double duration; 
        int rating;

        // Resto del código para leer y crear objetos Movie...
        getline(ss, token, ',');
        id = stoi(token);

        getline(ss, name, ',');
        getline(ss, token, ',');
        //cout << "Token: " << token << endl; DURATION MOVIE CORRECTO!
        duration = stod(token);

        getline(ss, genre, ',');
        getline(ss, token, ',');
      // cout << "Token: " << token << endl; RATING MOVIE CORRECTO!
        rating = stoi (token);

        /*cout << "ID: " << id << ", Name: " << name << ", Duration: " << duration << ", Genre: " << genre << ", Rating: " << rating << endl;*/

        Movie* movie = new Movie(id, name, duration, genre, rating);
        movies.push_back(movie);

        genreMap[genre].push_back(movie);

        ratingMap[rating].push_back(movie);

    }

    file.close();


  // 2. Lectura de archivos .txt para serie (herencia video) y episodio (composición serie)
  ifstream seriesFile("Series.txt");
  ifstream episodesFile("Episodios.txt");

  vector<Serie*> series;
  map<string, vector<Serie*>> genreMapSerie;
  map<double, vector<Serie*>> ratingMapSerie;

  if (!seriesFile.is_open() || !episodesFile.is_open()) {
      cout << "Error: Unable to open file." << endl;
      return 1; // Return an error code
  }

  string line2;
  while (getline(seriesFile, line2)) {
      stringstream ss(line2);
      string token;
      int id = 0;
      string name, genre;
      int rating;

      getline(ss, token, ',');
      id = stoi(token);
           

      getline(ss, name, ',');
      getline(ss, genre, ',');
      getline(ss, token, ',');
      rating = stoi(token);

      Serie* serie = new Serie(id, name, genre, rating);
      series.push_back(serie);

      genreMapSerie[genre].push_back(serie);
      ratingMapSerie[rating].push_back(serie);
  }

  seriesFile.close();

  // Leer y asignar episodios a las series
  while (getline(episodesFile, line2)) {
      stringstream ss(line2);
      string token;
      int idSerie, numSeason, rating;
      string idEpisode, name;
      double duration;
      //int rating;

      // Leer datos del episodio desde el archivo
      getline(ss, token, ',');
      idSerie = stoi(token);

      getline(ss, idEpisode, ',');
      getline(ss, name, ',');
      getline(ss, token, ',');
      duration = stod(token);
    /* PARA ATRAPAR ERRORES EN LÍNEAS DEL TEXTO!!!
      cout << "Token: " << token << endl;
      try { duration = stod(token);
           } catch (const std::invalid_argument& e) {
               cout << "Error: Token no es un número entero válido." << endl;
           }*/
    

      getline(ss, token, ',');
      rating = stoi(token);

      getline(ss, token, ',');
      numSeason = stoi(token);

      Episode* episode = new Episode(idSerie, idEpisode, name, duration, rating, numSeason);

      for (Serie* serie : series) {
          if (serie->getID() == idSerie) {
              serie->agregarEpisodio(episode);
              break; // Una vez que se asigna el episodio, se sale del ciclo
          }
      }
  }

  episodesFile.close();

  
    for (Movie* movie:movies) {
        movie -> showInfo();
        cout << "" << endl;
        cout << "" << endl;
    }

  cout << "" << endl;
  cout << "" << endl;
  cout << "" << endl;
  cout << "" << endl;
  
    for (Serie* serie : series) {
        serie->showInfo(); // Muestra información básica de la serie
        cout << "" << endl;
        cout << "" << endl;

        // Muestra información de todos los episodios de la serie
        for (Episode* episodio : serie->getEpisodes()) {
            episodio->showInfoEpisode();
          cout << "" << endl;
        }
      cout << "" << endl;
      cout << "" << endl;
      cout << "" << endl;
      cout << "" << endl;
    }

  // MENÚ INTERACTIVO
  

    return 0;
}